#1.
def multiplica(x,y):
    z=x*y
    print('O resultado de multiplicar', x, 'com', y, 'é igual a', z)

#2.
def right_justify(x):
    z=(70-len(x))*' '
    print(z,x)

#3.
def unidades(x):
    z=x%10
    print(z)


