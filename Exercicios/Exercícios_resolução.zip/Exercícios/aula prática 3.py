#1.
#1.1
def inteiros(x):
    for i in range(x):
        print(i)

#1.2
def soma_inteiros(x):
    z=1
    y=0
    while z<=x:
        y=y+z
        z=z+1
    return(y)

#teste=soma_inteiros(100)
#print(teste)

#2.
def quadrado():
    print('+','- '*4,'+','- '*4,'+')
    print('|',' '*8,'|',' '*8,'|')
    print('|',' '*8,'|',' '*8,'|')
    print('|',' '*8,'|',' '*8,'|')
    print('+','- '*4,'+','- '*4,'+')
    print('|',' '*8,'|',' '*8,'|')
    print('|',' '*8,'|',' '*8,'|')
    print('|',' '*8,'|',' '*8,'|')
    print('+','- '*4,'+','- '*4,'+')

#3.

