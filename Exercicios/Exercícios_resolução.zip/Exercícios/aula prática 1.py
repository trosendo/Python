#1.
#a) erro sintático
#b) erro sintático
#c) erro semântico
#d) erro semântico
#e) erro semântico
#f) erro sintático

#2.
#a)9992
#b)5
#c)8

#3.
#tf=float(input('tf='))
#tc=5/9*(tf-32)
#print(tc)

#4.
#D=float(input('D='))
#E=1.24362*D
#print(E)
